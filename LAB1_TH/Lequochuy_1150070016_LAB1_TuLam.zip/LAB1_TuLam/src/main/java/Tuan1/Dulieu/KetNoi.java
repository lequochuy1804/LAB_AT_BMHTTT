package Tuan1.Dulieu;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
public final class KetNoi {
    private static final String URL = "jdbc:sqlserver://";
    private static volatile Properties cauHinh;
    private KetNoi() {
    }
    public static Connection getConnection() throws SQLException {
        return moKetNoi();
    }
    public static Connection getConnection(String tenCSDL) throws SQLException {
        Properties thongTin = layCauHinh();
        dat(thongTin, "databaseName", tenCSDL == null ? null : tenCSDL.trim());
        return moVaLuu(thongTin);
    }
    public static Connection getConnection(String tenCSDL, String matKhau) throws SQLException {
        Properties thongTin = layCauHinh();
        dat(thongTin, "databaseName", tenCSDL == null ? null : tenCSDL.trim());
        dat(thongTin, "password", matKhau);
        return moVaLuu(thongTin);
    }
    public static Connection getConnection(String tenCSDL, String taiKhoan, String matKhau)
            throws SQLException {
        Properties thongTin = layCauHinh();
        dat(thongTin, "databaseName", tenCSDL == null ? null : tenCSDL.trim());
        dat(thongTin, "user", taiKhoan == null ? null : taiKhoan.trim());
        dat(thongTin, "password", matKhau);
        return moVaLuu(thongTin);
    }
    public static String kiemTra(String server, int port, String database, String user, String password)
            throws SQLException {
        Properties thongTin = taoCauHinh(server, Integer.toString(port), database, user, password,
                bienMoiTruong("LAB1_DB_INSTANCE", "LEQUOCHUY"));
        Properties truocDo = cauHinh;
        try (Connection connection = mo(thongTin)) {
            var metadata = connection.getMetaData();
            String ketQua = "Kết nối thành công: " + metadata.getDatabaseProductName() + " "
                    + metadata.getDatabaseProductVersion() + " - database " + connection.getCatalog();
            cauHinh = thongTin;
            return ketQua;
        } catch (SQLException ex) {
            if (cauHinh == truocDo) {
                cauHinh = null;
            }
            throw ex;
        }
    }
    public static boolean daKetNoi() {
        try {
            kiemTraThongTin(layCauHinh());
            return true;
        } catch (SQLException ex) {
            return false;
        }
    }
    public static void ngatKetNoi() {
        cauHinh = null;
    }
    public static Connection moKetNoi() throws SQLException {
        Properties dangDung = cauHinh;
        Properties thongTin = layCauHinh();
        Connection connection = mo(thongTin);
        if (dangDung == null && cauHinh == null) {
            cauHinh = thongTin;
        }
        return connection;
    }
    private static Connection moVaLuu(Properties thongTin) throws SQLException {
        Connection connection = mo(thongTin);
        cauHinh = thongTin;
        return connection;
    }
    private static Connection mo(Properties thongTin) throws SQLException {
        kiemTraThongTin(thongTin);
        Connection connection = DriverManager.getConnection(URL, thongTin);
        try {
            if (!connection.isValid(5)) {
                throw new SQLException("Kết nối SQL Server không còn hợp lệ.");
            }
            return connection;
        } catch (SQLException ex) {
            try {
                connection.close();
            } catch (SQLException closeException) {
                ex.addSuppressed(closeException);
            }
            throw ex;
        }
    }
    private static Properties layCauHinh() {
        Properties hienTai = cauHinh;
        if (hienTai != null) {
            return (Properties) hienTai.clone();
        }
        return taoCauHinh(bienMoiTruong("LAB1_DB_SERVER", "localhost"),
                bienMoiTruong("LAB1_DB_PORT", "14333"),
                bienMoiTruong("LAB1_DB_DATABASE", "LAB1_MaHoaCoDien"),
                bienMoiTruong("LAB1_DB_USER", "sa"), System.getenv("LAB1_DB_PASSWORD"),
                bienMoiTruong("LAB1_DB_INSTANCE", "LEQUOCHUY"));
    }
    private static Properties taoCauHinh(String server, String port, String database, String user,
            String password, String instance) {
        if (server != null && server.contains("\\")) {
            int viTri = server.indexOf('\\');
            instance = server.substring(viTri + 1).trim();
            server = server.substring(0, viTri);
        }
        Properties thongTin = new Properties();
        dat(thongTin, "serverName", server == null ? null : server.trim());
        dat(thongTin, "portNumber", port);
        dat(thongTin, "instanceName", instance);
        dat(thongTin, "databaseName", database == null ? null : database.trim());
        dat(thongTin, "user", user == null ? null : user.trim());
        dat(thongTin, "password", password);
        thongTin.setProperty("encrypt", "true");
        thongTin.setProperty("trustServerCertificate", "true");
        thongTin.setProperty("loginTimeout", "5");
        thongTin.setProperty("socketTimeout", "10000");
        return thongTin;
    }
    private static void kiemTraThongTin(Properties thongTin) throws SQLException {
        for (String ten : new String[]{"serverName", "databaseName", "user"}) {
            String giaTri = thongTin.getProperty(ten);
            if (giaTri == null || giaTri.isBlank()) {
                throw new SQLException("Server, Database và User không được để trống.");
            }
        }
        try {
            int port = Integer.parseInt(thongTin.getProperty("portNumber"));
            if (port < 1 || port > 65535) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            throw new SQLException("Port phải là số nguyên từ 1 đến 65535 (LAB1_DB_PORT).");
        }
        String password = thongTin.getProperty("password");
        if (password == null || password.isEmpty()) {
            throw new SQLException("Chưa có mật khẩu SQL Server. Nhập trên form hoặc đặt LAB1_DB_PASSWORD.");
        }
    }
    private static String bienMoiTruong(String ten, String macDinh) {
        String giaTri = System.getenv(ten);
        return giaTri == null ? macDinh : giaTri.trim();
    }
    private static void dat(Properties thongTin, String ten, String giaTri) {
        if (giaTri == null) {
            thongTin.remove(ten);
        } else {
            thongTin.setProperty(ten, giaTri);
        }
    }
}
