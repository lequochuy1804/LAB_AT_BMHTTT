package Tuan1.Dulieu;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;
public final class LichSu {
    private LichSu() {
    }
    public static void insert(String algorithm, String operation, String input, String result)
            throws SQLException {
        if (!"ENCRYPT".equals(operation) && !"DECRYPT".equals(operation)) {
            throw new IllegalArgumentException("Thao tác phải là ENCRYPT hoặc DECRYPT.");
        }
        String sql = "INSERT INTO dbo.history(algorithm, operation, input_text, result_text) VALUES (?, ?, ?, ?)";
        try (Connection connection = KetNoi.moKetNoi();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setNString(1, algorithm);
            statement.setString(2, operation);
            statement.setNString(3, input);
            statement.setNString(4, result);
            statement.executeUpdate();
        }
    }
    public static String tryInsert(String algorithm, String operation, String input, String result) {
        if (!KetNoi.daKetNoi()) {
            return "Chưa kết nối SQL Server nên chưa lưu lịch sử.";
        }
        try {
            insert(algorithm, operation, input, result);
            return "Đã lưu lịch sử vào SQL Server.";
        } catch (SQLException ex) {
            return "Lỗi lưu lịch sử: " + ex.getMessage();
        }
    }
    public static DefaultTableModel emptyModel() {
        return new DefaultTableModel(
                new Object[]{"ID", "Thời gian", "Thuật toán", "Thao tác", "Đầu vào", "Kết quả"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }
    public static DefaultTableModel loadLatest(int top) throws SQLException {
        if (top < 1 || top > 1000) {
            throw new IllegalArgumentException("Số dòng phải từ 1 đến 1000.");
        }
        DefaultTableModel model = emptyModel();
        String sql = "SELECT TOP (?) id, created_at, algorithm, operation, input_text, result_text "
                + "FROM dbo.history ORDER BY id DESC";
        try (Connection connection = KetNoi.moKetNoi();
                PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, top);
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    model.addRow(new Object[]{result.getLong(1), result.getTimestamp(2),
                        result.getNString(3), result.getString(4), result.getNString(5), result.getNString(6)});
                }
            }
        }
        return model;
    }
}
