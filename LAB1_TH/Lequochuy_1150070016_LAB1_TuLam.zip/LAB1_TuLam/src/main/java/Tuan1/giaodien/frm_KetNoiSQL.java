package Tuan1.giaodien;
import Tuan1.Dulieu.KetNoi;
public class frm_KetNoiSQL extends javax.swing.JFrame {
    public frm_KetNoiSQL() {
        initComponents();
        setLocationRelativeTo(null);
    }
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Kết nối Microsoft SQL Server");
        getContentPane().setLayout(new java.awt.BorderLayout());
        panel_main = new javax.swing.JPanel();
        panel_main.setBackground(new java.awt.Color(214, 217, 223));
        panel_main.setPreferredSize(new java.awt.Dimension(580, 360));
        panel_main.setLayout(new java.awt.GridBagLayout());
        lbl_title = new javax.swing.JLabel();
        lbl_title.setText("KẾT NỐI MICROSOFT SQL SERVER");
        lbl_title.setFont(new java.awt.Font("Segoe UI", 1, 18));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(20, 20, 16, 20);
        panel_main.add(lbl_title, gridBagConstraints);
        lbl_server = new javax.swing.JLabel();
        lbl_server.setText("Server:");
        lbl_server.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_server.setPreferredSize(new java.awt.Dimension(98, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_server, gridBagConstraints);
        txt_server = new javax.swing.JTextField();
        txt_server.setText("127.0.0.1");
        txt_server.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_server.setPreferredSize(new java.awt.Dimension(320, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(txt_server, gridBagConstraints);
        lbl_port = new javax.swing.JLabel();
        lbl_port.setText("Port:");
        lbl_port.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_port.setPreferredSize(new java.awt.Dimension(98, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_port, gridBagConstraints);
        txt_port = new javax.swing.JTextField();
        txt_port.setText("14333");
        txt_port.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_port.setPreferredSize(new java.awt.Dimension(120, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(txt_port, gridBagConstraints);
        lbl_database = new javax.swing.JLabel();
        lbl_database.setText("Database:");
        lbl_database.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_database.setPreferredSize(new java.awt.Dimension(98, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_database, gridBagConstraints);
        txt_database = new javax.swing.JTextField();
        txt_database.setText("LAB1_MaHoaCoDien");
        txt_database.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_database.setPreferredSize(new java.awt.Dimension(320, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(txt_database, gridBagConstraints);
        lbl_user = new javax.swing.JLabel();
        lbl_user.setText("User:");
        lbl_user.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_user.setPreferredSize(new java.awt.Dimension(98, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_user, gridBagConstraints);
        txt_user = new javax.swing.JTextField();
        txt_user.setText("sa");
        txt_user.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_user.setPreferredSize(new java.awt.Dimension(320, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(txt_user, gridBagConstraints);
        lbl_password = new javax.swing.JLabel();
        lbl_password.setText("Password:");
        lbl_password.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_password.setPreferredSize(new java.awt.Dimension(98, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_password, gridBagConstraints);
        txt_password = new javax.swing.JPasswordField();
        txt_password.setText("");
        txt_password.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_password.setPreferredSize(new java.awt.Dimension(320, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(txt_password, gridBagConstraints);
        panel_actions = new javax.swing.JPanel();
        panel_actions.setBackground(new java.awt.Color(214, 217, 223));
        panel_actions.setLayout(new java.awt.GridBagLayout());
        btn_test = new javax.swing.JButton();
        btn_test.setText("Test Connection");
        btn_test.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_test.setPreferredSize(new java.awt.Dimension(150, 28));
        btn_test.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_testActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_actions.add(btn_test, gridBagConstraints);
        btn_history = new javax.swing.JButton();
        btn_history.setText("Xem lịch sử");
        btn_history.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_history.setPreferredSize(new java.awt.Dimension(130, 28));
        btn_history.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_historyActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 14, 0, 0);
        panel_actions.add(btn_history, gridBagConstraints);
        panel_actions_space = new javax.swing.JLabel();
        panel_actions_space.setText("");
        panel_actions_space.setFont(new java.awt.Font("Segoe UI", 0, 12));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_actions.add(panel_actions_space, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(panel_actions, gridBagConstraints);
        lbl_status = new javax.swing.JLabel();
        lbl_status.setText("Chưa kết nối.");
        lbl_status.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_status.setPreferredSize(new java.awt.Dimension(520, 50));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 7;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 16, 20);
        panel_main.add(lbl_status, gridBagConstraints);
        getContentPane().add(panel_main, java.awt.BorderLayout.CENTER);
        pack();
    }
    private void btn_historyActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_LichSu().setVisible(true);
    }
    private void btn_testActionPerformed(java.awt.event.ActionEvent evt) {
        int port;
        try {
            port = Integer.parseInt(txt_port.getText().trim());
            if (port < 1 || port > 65535) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            hienLoi("Port phải là số nguyên từ 1 đến 65535.");
            return;
        }
        String server = txt_server.getText().trim();
        String database = txt_database.getText().trim();
        String user = txt_user.getText().trim();
        String password = new String(txt_password.getPassword());
        if (server.isEmpty() || database.isEmpty() || user.isEmpty()) {
            hienLoi("Server, Database và User không được để trống.");
            return;
        }
        btn_test.setEnabled(false);
        trangThai("Đang kiểm tra kết nối...");
        new javax.swing.SwingWorker<String, Void>() {
            @Override protected String doInBackground() throws Exception {
                return KetNoi.kiemTra(server, port, database, user, password);
            }
            @Override protected void done() {
                btn_test.setEnabled(true);
                try { trangThai(get()); }
                catch (Exception ex) {
                    Throwable cause = ex.getCause() == null ? ex : ex.getCause();
                    hienLoi("Kết nối thất bại: " + cause.getMessage());
                }
            }
        }.execute();
    }
    private void trangThai(String text) {
        lbl_status.setText("<html>" + text.replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;") + "</html>");
        lbl_status.setToolTipText(text);
    }
    private void hienLoi(String message) {
        trangThai(message);
        javax.swing.JOptionPane.showMessageDialog(this, message, "Thông báo",
                javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new frm_KetNoiSQL().setVisible(true));
    }
    private javax.swing.JPanel panel_main;
    private javax.swing.JLabel lbl_title;
    private javax.swing.JLabel lbl_server;
    private javax.swing.JTextField txt_server;
    private javax.swing.JLabel lbl_port;
    private javax.swing.JTextField txt_port;
    private javax.swing.JLabel lbl_database;
    private javax.swing.JTextField txt_database;
    private javax.swing.JLabel lbl_user;
    private javax.swing.JTextField txt_user;
    private javax.swing.JLabel lbl_password;
    private javax.swing.JPasswordField txt_password;
    private javax.swing.JPanel panel_actions;
    private javax.swing.JButton btn_test;
    private javax.swing.JButton btn_history;
    private javax.swing.JLabel panel_actions_space;
    private javax.swing.JLabel lbl_status;
}
