package Tuan1.giaodien;
import Tuan1.Dulieu.KetNoi;
import Tuan1.Dulieu.LichSu;
public class frm_LichSu extends javax.swing.JFrame {
    public frm_LichSu() {
        initComponents();
        setLocationRelativeTo(null);
        tbl_history.setModel(LichSu.emptyModel());
        loadData();
    }
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Lịch sử thao tác (SQL Server)");
        getContentPane().setLayout(new java.awt.BorderLayout());
        panel_main = new javax.swing.JPanel();
        panel_main.setBackground(new java.awt.Color(214, 217, 223));
        panel_main.setPreferredSize(new java.awt.Dimension(900, 390));
        panel_main.setLayout(new java.awt.GridBagLayout());
        lbl_title = new javax.swing.JLabel();
        lbl_title.setText("LỊCH SỬ THAO TÁC - BẢNG DBO.HISTORY");
        lbl_title.setFont(new java.awt.Font("Segoe UI", 1, 18));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(20, 20, 16, 20);
        panel_main.add(lbl_title, gridBagConstraints);
        scroll_history = new javax.swing.JScrollPane();
        scroll_history.setPreferredSize(new java.awt.Dimension(860, 260));
        tbl_history = new javax.swing.JTable();
        tbl_history.setRowHeight(26);
        scroll_history.setViewportView(tbl_history);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 14, 20);
        panel_main.add(scroll_history, gridBagConstraints);
        btn_refresh = new javax.swing.JButton();
        btn_refresh.setText("Tải lại");
        btn_refresh.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_refresh.setPreferredSize(new java.awt.Dimension(110, 28));
        btn_refresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_refreshActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 16, 14);
        panel_main.add(btn_refresh, gridBagConstraints);
        lbl_status = new javax.swing.JLabel();
        lbl_status.setText("Đang tải...");
        lbl_status.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_status.setPreferredSize(new java.awt.Dimension(720, 40));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 16, 20);
        panel_main.add(lbl_status, gridBagConstraints);
        getContentPane().add(panel_main, java.awt.BorderLayout.CENTER);
        pack();
    }
    private void btn_refreshActionPerformed(java.awt.event.ActionEvent evt) {
        loadData();
    }
    private void loadData() {
        if (!KetNoi.daKetNoi()) {
            trangThai("Chưa kết nối SQL Server. Hãy mở form kết nối và bấm Test Connection.");
            return;
        }
        btn_refresh.setEnabled(false);
        trangThai("Đang tải lịch sử...");
        new javax.swing.SwingWorker<javax.swing.table.DefaultTableModel, Void>() {
            @Override protected javax.swing.table.DefaultTableModel doInBackground() throws Exception {
                return LichSu.loadLatest(50);
            }
            @Override protected void done() {
                btn_refresh.setEnabled(true);
                try {
                    tbl_history.setModel(get());
                    trangThai("Đã tải " + tbl_history.getRowCount() + " dòng mới nhất từ dbo.history.");
                } catch (Exception ex) {
                    Throwable cause = ex.getCause() == null ? ex : ex.getCause();
                    trangThai("Không đọc được lịch sử: " + cause.getMessage());
                }
            }
        }.execute();
    }
    private void trangThai(String text) {
        lbl_status.setText("<html>" + text.replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;") + "</html>");
        lbl_status.setToolTipText(text);
    }
    private void hienLoi(String message) {
        trangThai(message);
        javax.swing.JOptionPane.showMessageDialog(this, message, "Thông báo",
                javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new frm_LichSu().setVisible(true));
    }
    private javax.swing.JPanel panel_main;
    private javax.swing.JLabel lbl_title;
    private javax.swing.JScrollPane scroll_history;
    private javax.swing.JTable tbl_history;
    private javax.swing.JButton btn_refresh;
    private javax.swing.JLabel lbl_status;
}
