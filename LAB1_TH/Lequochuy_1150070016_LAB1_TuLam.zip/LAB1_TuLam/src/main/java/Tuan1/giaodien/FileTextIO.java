package Tuan1.giaodien;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Locale;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileNameExtensionFilter;
public final class FileTextIO {
    private FileTextIO() {
    }
    public static String openText(JFrame parent, JTextArea target) {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileFilter(new FileNameExtensionFilter("Text file (*.txt)", "txt"));
        if (chooser.showOpenDialog(parent) != JFileChooser.APPROVE_OPTION) {
            return null;
        }
        File file = chooser.getSelectedFile();
        try {
            target.setText(Files.readString(file.toPath(), StandardCharsets.UTF_8));
            return file.getAbsolutePath();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(parent, "Không đọc được tệp: " + ex.getMessage(),
                    "Lỗi mở tệp", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }
    public static String saveText(JFrame parent, JTextArea source, String defaultName) {
        if (source.getText().isEmpty()) {
            JOptionPane.showMessageDialog(parent, "Chưa có nội dung để lưu.");
            return null;
        }
        JFileChooser chooser = new JFileChooser();
        chooser.setFileFilter(new FileNameExtensionFilter("Text file (*.txt)", "txt"));
        chooser.setSelectedFile(new File(defaultName));
        if (chooser.showSaveDialog(parent) != JFileChooser.APPROVE_OPTION) {
            return null;
        }
        File file = chooser.getSelectedFile();
        if (!file.getName().toLowerCase(Locale.ROOT).endsWith(".txt")) {
            file = new File(file.getParentFile(), file.getName() + ".txt");
        }
        if (file.exists() && JOptionPane.showConfirmDialog(parent,
                "Tệp đã tồn tại. Bạn có muốn ghi đè?", "Lưu tệp",
                JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) {
            return null;
        }
        try {
            Files.writeString(file.toPath(), source.getText(), StandardCharsets.UTF_8);
            return file.getAbsolutePath();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(parent, "Không lưu được tệp: " + ex.getMessage(),
                    "Lỗi lưu tệp", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }
}
