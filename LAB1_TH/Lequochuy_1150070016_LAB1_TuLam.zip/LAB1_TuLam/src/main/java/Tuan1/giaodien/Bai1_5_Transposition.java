package Tuan1.giaodien;
public class Bai1_5_Transposition extends javax.swing.JFrame {
    public Bai1_5_Transposition() {
        initComponents();
        setLocationRelativeTo(null);
    }
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Transposition Cipher");
        getContentPane().setLayout(new java.awt.BorderLayout());
        panel_main = new javax.swing.JPanel();
        panel_main.setBackground(new java.awt.Color(214, 217, 223));
        panel_main.setPreferredSize(new java.awt.Dimension(720, 336));
        panel_main.setLayout(new java.awt.GridBagLayout());
        lbl_title = new javax.swing.JLabel();
        lbl_title.setText("MẬT MÃ HOÁN VỊ CỘT (TRANSPOSITION)");
        lbl_title.setFont(new java.awt.Font("Segoe UI", 1, 18));
        lbl_title.setPreferredSize(new java.awt.Dimension(570, 34));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(20, 20, 8, 20);
        panel_main.add(lbl_title, gridBagConstraints);
        lbl_plaintext = new javax.swing.JLabel();
        lbl_plaintext.setText("Plaintext:");
        lbl_plaintext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_plaintext.setPreferredSize(new java.awt.Dimension(98, 22));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 14, 14);
        panel_main.add(lbl_plaintext, gridBagConstraints);
        scroll_plaintext = new javax.swing.JScrollPane();
        scroll_plaintext.setPreferredSize(new java.awt.Dimension(566, 66));
        txt_plaintext = new javax.swing.JTextArea();
        txt_plaintext.setColumns(40);
        txt_plaintext.setRows(3);
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        scroll_plaintext.setViewportView(txt_plaintext);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 1;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 14, 20);
        panel_main.add(scroll_plaintext, gridBagConstraints);
        lbl_key = new javax.swing.JLabel();
        lbl_key.setText("Key:");
        lbl_key.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_key.setPreferredSize(new java.awt.Dimension(98, 24));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 14, 14);
        panel_main.add(lbl_key, gridBagConstraints);
        panel_key = new javax.swing.JPanel();
        panel_key.setBackground(new java.awt.Color(214, 217, 223));
        panel_key.setLayout(new java.awt.GridBagLayout());
        txt_key = new javax.swing.JTextField();
        txt_key.setText("2,3,1");
        txt_key.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_key.setPreferredSize(new java.awt.Dimension(146, 24));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_key.add(txt_key, gridBagConstraints);
        lbl_hint = new javax.swing.JLabel();
        lbl_hint.setText("Thứ tự đọc cột, cách nhau dấu phẩy, ví dụ 2,3,1");
        lbl_hint.setFont(new java.awt.Font("Segoe UI", 0, 12));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 14, 0, 0);
        panel_key.add(lbl_hint, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 14, 20);
        panel_main.add(panel_key, gridBagConstraints);
        lbl_ciphertext = new javax.swing.JLabel();
        lbl_ciphertext.setText("Ciphertext:");
        lbl_ciphertext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 16, 14);
        panel_main.add(lbl_ciphertext, gridBagConstraints);
        scroll_ciphertext = new javax.swing.JScrollPane();
        scroll_ciphertext.setPreferredSize(new java.awt.Dimension(566, 66));
        txt_ciphertext = new javax.swing.JTextArea();
        txt_ciphertext.setColumns(40);
        txt_ciphertext.setRows(3);
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        scroll_ciphertext.setViewportView(txt_ciphertext);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 1;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 16, 20);
        panel_main.add(scroll_ciphertext, gridBagConstraints);
        panel_actions = new javax.swing.JPanel();
        panel_actions.setBackground(new java.awt.Color(214, 217, 223));
        panel_actions.setLayout(new java.awt.GridBagLayout());
        btn_encrypt = new javax.swing.JButton();
        btn_encrypt.setText("Encrypt");
        btn_encrypt.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_encrypt.setPreferredSize(new java.awt.Dimension(96, 26));
        btn_encrypt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_encryptActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_actions.add(btn_encrypt, gridBagConstraints);
        btn_decrypt = new javax.swing.JButton();
        btn_decrypt.setText("Decrypt");
        btn_decrypt.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_decrypt.setPreferredSize(new java.awt.Dimension(96, 26));
        btn_decrypt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_decryptActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 14, 0, 0);
        panel_actions.add(btn_decrypt, gridBagConstraints);
        btn_open = new javax.swing.JButton();
        btn_open.setText("Open Ciphertext File");
        btn_open.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_open.setPreferredSize(new java.awt.Dimension(166, 26));
        btn_open.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_openActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 14, 0, 0);
        panel_actions.add(btn_open, gridBagConstraints);
        btn_save = new javax.swing.JButton();
        btn_save.setText("Save Ciphertext File");
        btn_save.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_save.setPreferredSize(new java.awt.Dimension(166, 26));
        btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_saveActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 14, 0, 0);
        panel_actions.add(btn_save, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 16, 20);
        panel_main.add(panel_actions, gridBagConstraints);
        lbl_status = new javax.swing.JLabel();
        lbl_status.setText("Sẵn sàng.");
        lbl_status.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_status.setPreferredSize(new java.awt.Dimension(566, 22));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(lbl_status, gridBagConstraints);
        getContentPane().add(panel_main, java.awt.BorderLayout.CENTER);
        pack();
    }
    private void btn_encryptActionPerformed(java.awt.event.ActionEvent evt) {
        String text = txt_plaintext.getText();
        if (text.isEmpty()) {
            showError("Hãy nhập Plaintext trước khi mã hóa.");
            return;
        }
        try {
            int[] key = Bai1_5_Transposition.parseKey(txt_key.getText());
            txt_ciphertext.setText(Bai1_5_Transposition.encrypt(text, key));
            lbl_status.setText("Đã mã hóa.");
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }
    private void btn_decryptActionPerformed(java.awt.event.ActionEvent evt) {
        String text = txt_ciphertext.getText();
        if (text.isEmpty()) {
            showError("Hãy nhập Ciphertext trước khi giải mã.");
            return;
        }
        try {
            int[] key = Bai1_5_Transposition.parseKey(txt_key.getText());
            txt_plaintext.setText(Bai1_5_Transposition.decrypt(text, key));
            lbl_status.setText("Đã giải mã.");
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }
    private void btn_openActionPerformed(java.awt.event.ActionEvent evt) {
        String path = FileTextIO.openText(this, txt_ciphertext);
        if (path != null) lbl_status.setText("Đã mở tệp: " + path);
    }
    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {
        String path = FileTextIO.saveText(this, txt_ciphertext, "transposition_ciphertext.txt");
        if (path != null) lbl_status.setText("Đã lưu tệp: " + path);
    }
    private void showError(String message) {
        lbl_status.setText(message);
        javax.swing.JOptionPane.showMessageDialog(this, message, "Dữ liệu không hợp lệ",
                javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new Bai1_5_Transposition().setVisible(true));
    }
    private javax.swing.JPanel panel_main;
    private javax.swing.JLabel lbl_title;
    private javax.swing.JLabel lbl_plaintext;
    private javax.swing.JScrollPane scroll_plaintext;
    private javax.swing.JTextArea txt_plaintext;
    private javax.swing.JLabel lbl_key;
    private javax.swing.JPanel panel_key;
    private javax.swing.JTextField txt_key;
    private javax.swing.JLabel lbl_hint;
    private javax.swing.JLabel lbl_ciphertext;
    private javax.swing.JScrollPane scroll_ciphertext;
    private javax.swing.JTextArea txt_ciphertext;
    private javax.swing.JPanel panel_actions;
    private javax.swing.JButton btn_encrypt;
    private javax.swing.JButton btn_decrypt;
    private javax.swing.JButton btn_open;
    private javax.swing.JButton btn_save;
    private javax.swing.JLabel lbl_status;
public static String encrypt(String text, int[] key) {
        return process(text, key, true);
    }
    public static String decrypt(String text, int[] key) {
        return process(text, key, false);
    }
    public static int[] parseKey(String keyText) {
        String[] parts = keyText.trim().split("\\s*,\\s*", -1);
        int[] key = new int[parts.length];
        try {
            for (int i = 0; i < parts.length; i++) {
                key[i] = Integer.parseInt(parts[i]);
            }
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Khóa phải là các số cách nhau bởi dấu phẩy, ví dụ 2,3,1.");
        }
        validateKey(key);
        return key;
    }
    private static void validateKey(int[] key) {
        if (key == null || key.length < 2 || key.length > 50) {
            throw new IllegalArgumentException("Khóa phải có từ 2 đến 50 cột.");
        }
        boolean[] used = new boolean[key.length + 1];
        for (int col : key) {
            if (col < 1 || col > key.length || used[col]) {
                throw new IllegalArgumentException("Khóa phải là hoán vị 1..m.");
            }
            used[col] = true;
        }
    }
    private static String process(String text, int[] key, boolean encrypt) {
        validateKey(key);
        int[] chars = text.codePoints().toArray();
        int length = chars.length;
        int columns = key.length;
        int rows = (length + columns - 1) / columns;
        int[][] grid = new int[rows][columns];
        int offset = 0;
        if (encrypt) {
            for (int i = 0; i < length; i++) {
                grid[i / columns][i % columns] = chars[i];
            }
            int[] result = new int[length];
            for (int column : key) {
                for (int row = 0; row < rows; row++) {
                    if (row * columns + column - 1 < length) {
                        result[offset++] = grid[row][column - 1];
                    }
                }
            }
            return new String(result, 0, result.length);
        }
        for (int column : key) {
            for (int row = 0; row < rows; row++) {
                if (row * columns + column - 1 < length) {
                    grid[row][column - 1] = chars[offset++];
                }
            }
        }
        int[] result = new int[length];
        for (int i = 0; i < length; i++) {
            result[i] = grid[i / columns][i % columns];
        }
        return new String(result, 0, result.length);
    }
}
