package Tuan1.giaodien;
import Tuan1.Dulieu.KetNoi;
import Tuan1.Dulieu.LichSu;
public class bai1nangcao extends javax.swing.JFrame {
    public bai1nangcao() {
        initComponents();
        setLocationRelativeTo(null);
    }
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Chương trình tổng hợp - 6 thuật toán");
        getContentPane().setLayout(new java.awt.BorderLayout());
        panel_main = new javax.swing.JPanel();
        panel_main.setBackground(new java.awt.Color(214, 217, 223));
        panel_main.setPreferredSize(new java.awt.Dimension(780, 446));
        panel_main.setLayout(new java.awt.GridBagLayout());
        lbl_title = new javax.swing.JLabel();
        lbl_title.setText("CHƯƠNG TRÌNH TỔNG HỢP 6 THUẬT TOÁN CỔ ĐIỂN");
        lbl_title.setFont(new java.awt.Font("Segoe UI", 1, 18));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(20, 20, 14, 20);
        panel_main.add(lbl_title, gridBagConstraints);
        lbl_algorithm = new javax.swing.JLabel();
        lbl_algorithm.setText("Thuật toán:");
        lbl_algorithm.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_algorithm.setPreferredSize(new java.awt.Dimension(98, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 12, 14);
        panel_main.add(lbl_algorithm, gridBagConstraints);
        panel_algorithm = new javax.swing.JPanel();
        panel_algorithm.setBackground(new java.awt.Color(214, 217, 223));
        panel_algorithm.setLayout(new java.awt.GridBagLayout());
        cbo_algorithm = new javax.swing.JComboBox<>();
        cbo_algorithm.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] {"Caesar", "Vigenere", "Rail Fence", "Playfair", "Transposition", "Autokey"}));
        cbo_algorithm.setFont(new java.awt.Font("Segoe UI", 0, 12));
        cbo_algorithm.setPreferredSize(new java.awt.Dimension(180, 28));
        cbo_algorithm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbo_algorithmActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 14);
        panel_algorithm.add(cbo_algorithm, gridBagConstraints);
        lbl_hint = new javax.swing.JLabel();
        lbl_hint.setText("Khóa mẫu: 3");
        lbl_hint.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_hint.setPreferredSize(new java.awt.Dimension(410, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_algorithm.add(lbl_hint, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(panel_algorithm, gridBagConstraints);
        lbl_plaintext = new javax.swing.JLabel();
        lbl_plaintext.setText("Plaintext:");
        lbl_plaintext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 12, 14);
        panel_main.add(lbl_plaintext, gridBagConstraints);
        scroll_txt_plaintext = new javax.swing.JScrollPane();
        scroll_txt_plaintext.setPreferredSize(new java.awt.Dimension(620, 70));
        txt_plaintext = new javax.swing.JTextArea();
        txt_plaintext.setColumns(40);
        txt_plaintext.setRows(3);
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);
        txt_plaintext.setEditable(true);
        txt_plaintext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        scroll_txt_plaintext.setViewportView(txt_plaintext);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(scroll_txt_plaintext, gridBagConstraints);
        lbl_key = new javax.swing.JLabel();
        lbl_key.setText("Key:");
        lbl_key.setFont(new java.awt.Font("Segoe UI", 0, 12));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 12, 14);
        panel_main.add(lbl_key, gridBagConstraints);
        txt_key = new javax.swing.JTextField();
        txt_key.setText("3");
        txt_key.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_key.setPreferredSize(new java.awt.Dimension(200, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(txt_key, gridBagConstraints);
        lbl_ciphertext = new javax.swing.JLabel();
        lbl_ciphertext.setText("Ciphertext:");
        lbl_ciphertext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 12, 14);
        panel_main.add(lbl_ciphertext, gridBagConstraints);
        scroll_txt_ciphertext = new javax.swing.JScrollPane();
        scroll_txt_ciphertext.setPreferredSize(new java.awt.Dimension(620, 70));
        txt_ciphertext = new javax.swing.JTextArea();
        txt_ciphertext.setColumns(40);
        txt_ciphertext.setRows(3);
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setWrapStyleWord(true);
        txt_ciphertext.setEditable(true);
        txt_ciphertext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        scroll_txt_ciphertext.setViewportView(txt_ciphertext);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(scroll_txt_ciphertext, gridBagConstraints);
        panel_actions = new javax.swing.JPanel();
        panel_actions.setBackground(new java.awt.Color(214, 217, 223));
        panel_actions.setLayout(new java.awt.GridBagLayout());
        btn_encrypt = new javax.swing.JButton();
        btn_encrypt.setText("Encrypt");
        btn_encrypt.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_encrypt.setPreferredSize(new java.awt.Dimension(96, 28));
        btn_encrypt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_encryptActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_actions.add(btn_encrypt, gridBagConstraints);
        btn_decrypt = new javax.swing.JButton();
        btn_decrypt.setText("Decrypt");
        btn_decrypt.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_decrypt.setPreferredSize(new java.awt.Dimension(96, 28));
        btn_decrypt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_decryptActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 14, 0, 0);
        panel_actions.add(btn_decrypt, gridBagConstraints);
        btn_open = new javax.swing.JButton();
        btn_open.setText("Open File");
        btn_open.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_open.setPreferredSize(new java.awt.Dimension(110, 28));
        btn_open.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_openActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 14, 0, 0);
        panel_actions.add(btn_open, gridBagConstraints);
        btn_save = new javax.swing.JButton();
        btn_save.setText("Save File");
        btn_save.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_save.setPreferredSize(new java.awt.Dimension(110, 28));
        btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_saveActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 14, 0, 0);
        panel_actions.add(btn_save, gridBagConstraints);
        panel_actions_space = new javax.swing.JLabel();
        panel_actions_space.setText("");
        panel_actions_space.setFont(new java.awt.Font("Segoe UI", 0, 12));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_actions.add(panel_actions_space, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(panel_actions, gridBagConstraints);
        panel_sql = new javax.swing.JPanel();
        panel_sql.setBackground(new java.awt.Color(214, 217, 223));
        panel_sql.setLayout(new java.awt.GridBagLayout());
        btn_sql = new javax.swing.JButton();
        btn_sql.setText("Kết nối SQL Server");
        btn_sql.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_sql.setPreferredSize(new java.awt.Dimension(170, 28));
        btn_sql.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_sqlActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_sql.add(btn_sql, gridBagConstraints);
        btn_history = new javax.swing.JButton();
        btn_history.setText("Xem lịch sử");
        btn_history.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_history.setPreferredSize(new java.awt.Dimension(130, 28));
        btn_history.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_historyActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 14, 0, 0);
        panel_sql.add(btn_history, gridBagConstraints);
        panel_sql_space = new javax.swing.JLabel();
        panel_sql_space.setText("");
        panel_sql_space.setFont(new java.awt.Font("Segoe UI", 0, 12));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_sql.add(panel_sql_space, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(panel_sql, gridBagConstraints);
        lbl_status = new javax.swing.JLabel();
        lbl_status.setText("Sẵn sàng.");
        lbl_status.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_status.setPreferredSize(new java.awt.Dimension(620, 44));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 7;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 16, 20);
        panel_main.add(lbl_status, gridBagConstraints);
        getContentPane().add(panel_main, java.awt.BorderLayout.CENTER);
        pack();
    }
    private void cbo_algorithmActionPerformed(java.awt.event.ActionEvent evt) {
        String algorithm = (String) cbo_algorithm.getSelectedItem();
        txt_key.setText(bai1nangcao.sampleKey(algorithm));
        lbl_hint.setText("Khóa mẫu: " + bai1nangcao.sampleKey(algorithm));
    }
    private void btn_encryptActionPerformed(java.awt.event.ActionEvent evt) {
        xuLy(true);
    }
    private void btn_decryptActionPerformed(java.awt.event.ActionEvent evt) {
        xuLy(false);
    }
    private void btn_sqlActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_KetNoiSQL().setVisible(true);
    }
    private void btn_historyActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_LichSu().setVisible(true);
    }
    private void btn_openActionPerformed(java.awt.event.ActionEvent evt) {
        String path = FileTextIO.openText(this, txt_ciphertext);
        if (path != null) trangThai("Đã mở tệp: " + path);
    }
    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {
        String path = FileTextIO.saveText(this, txt_ciphertext, "ciphertext.txt");
        if (path != null) trangThai("Đã lưu tệp: " + path);
    }
    private void xuLy(boolean encrypt) {
        String algorithm = (String) cbo_algorithm.getSelectedItem();
        String input = (encrypt ? txt_plaintext : txt_ciphertext).getText();
        try {
            String result = encrypt ? bai1nangcao.encrypt(algorithm, input, txt_key.getText())
                    : bai1nangcao.decrypt(algorithm, input, txt_key.getText());
            (encrypt ? txt_ciphertext : txt_plaintext).setText(result);
            String status = (encrypt ? "Đã mã hóa " : "Đã giải mã ") + algorithm + ". ";
            if (!KetNoi.daKetNoi()) {
                trangThai(status + "Chưa kết nối SQL Server nên chưa lưu lịch sử.");
                return;
            }
            choXuLy(false);
            trangThai(status + "Đang lưu lịch sử...");
            new javax.swing.SwingWorker<String, Void>() {
                @Override protected String doInBackground() {
                    return LichSu.tryInsert(algorithm, encrypt ? "ENCRYPT" : "DECRYPT", input, result);
                }
                @Override protected void done() {
                    choXuLy(true);
                    try { trangThai(status + get()); }
                    catch (Exception ex) { trangThai(status + "Không lưu được lịch sử: " + ex.getMessage()); }
                }
            }.execute();
        } catch (IllegalArgumentException ex) {
            hienLoi(ex.getMessage());
        }
    }
    private void choXuLy(boolean enabled) {
        btn_encrypt.setEnabled(enabled);
        btn_decrypt.setEnabled(enabled);
        btn_open.setEnabled(enabled);
        btn_save.setEnabled(enabled);
        cbo_algorithm.setEnabled(enabled);
        txt_key.setEditable(enabled);
        txt_plaintext.setEditable(enabled);
        txt_ciphertext.setEditable(enabled);
    }
    private void trangThai(String text) {
        lbl_status.setText("<html>" + text.replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;") + "</html>");
        lbl_status.setToolTipText(text);
    }
    private void hienLoi(String message) {
        trangThai(message);
        javax.swing.JOptionPane.showMessageDialog(this, message, "Thông báo",
                javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new bai1nangcao().setVisible(true));
    }
    private javax.swing.JPanel panel_main;
    private javax.swing.JLabel lbl_title;
    private javax.swing.JLabel lbl_algorithm;
    private javax.swing.JPanel panel_algorithm;
    private javax.swing.JComboBox<String> cbo_algorithm;
    private javax.swing.JLabel lbl_hint;
    private javax.swing.JLabel lbl_plaintext;
    private javax.swing.JScrollPane scroll_txt_plaintext;
    private javax.swing.JTextArea txt_plaintext;
    private javax.swing.JLabel lbl_key;
    private javax.swing.JTextField txt_key;
    private javax.swing.JLabel lbl_ciphertext;
    private javax.swing.JScrollPane scroll_txt_ciphertext;
    private javax.swing.JTextArea txt_ciphertext;
    private javax.swing.JPanel panel_actions;
    private javax.swing.JButton btn_encrypt;
    private javax.swing.JButton btn_decrypt;
    private javax.swing.JButton btn_open;
    private javax.swing.JButton btn_save;
    private javax.swing.JLabel panel_actions_space;
    private javax.swing.JPanel panel_sql;
    private javax.swing.JButton btn_sql;
    private javax.swing.JButton btn_history;
    private javax.swing.JLabel panel_sql_space;
    private javax.swing.JLabel lbl_status;
    public static final String[] ALGORITHMS = {
        "Caesar", "Vigenere", "Rail Fence", "Playfair", "Transposition", "Autokey"
    };
public static String encrypt(String algorithm, String text, String key) {
        return process(algorithm, text, key, true);
    }
    public static String decrypt(String algorithm, String text, String key) {
        return process(algorithm, text, key, false);
    }
    public static String sampleKey(String algorithm) {
        if (algorithm == null) {
            throw new IllegalArgumentException("Chưa chọn thuật toán.");
        }
        return switch (algorithm) {
            case "Caesar", "Rail Fence" -> "3";
            case "Vigenere", "Autokey" -> "KEY";
            case "Playfair" -> "KEYWORD";
            case "Transposition" -> "2,3,1";
            default -> throw new IllegalArgumentException("Thuật toán không hỗ trợ: " + algorithm);
        };
    }
    private static String process(String algorithm, String text, String key, boolean encrypt) {
        if (algorithm == null || algorithm.isBlank()) {
            throw new IllegalArgumentException("Chưa chọn thuật toán.");
        }
        if (text == null || text.isEmpty()) {
            throw new IllegalArgumentException("Chưa nhập dữ liệu.");
        }
        if (key == null || key.isBlank()) {
            throw new IllegalArgumentException("Chưa nhập khóa.");
        }
        key = key.trim();
        switch (algorithm) {
            case "Caesar":
                int caesarKey = parseInt(key, "Khóa Caesar phải là số nguyên, ví dụ 3.");
                return encrypt ? Bai1_1_Caesar.encrypt(text, caesarKey)
                        : Bai1_1_Caesar.decrypt(text, caesarKey);
            case "Vigenere":
                return encrypt ? Bai1_2_Vigenere.encrypt(text, key)
                        : Bai1_2_Vigenere.decrypt(text, key);
            case "Rail Fence":
                int rails = parseInt(key, "Số hàng Rail Fence phải là số nguyên, ví dụ 3.");
                return encrypt ? Bai1_3_RailFence.encrypt(text, rails)
                        : Bai1_3_RailFence.decrypt(text, rails);
            case "Playfair":
                return encrypt ? Bai1_4_Playfair.encrypt(text, key)
                        : Bai1_4_Playfair.decrypt(text, key);
            case "Transposition":
                int[] order = Bai1_5_Transposition.parseKey(key);
                return encrypt ? Bai1_5_Transposition.encrypt(text, order)
                        : Bai1_5_Transposition.decrypt(text, order);
            case "Autokey":
                return encrypt ? Bai1_6_Autokey.encrypt(text, key)
                        : Bai1_6_Autokey.decrypt(text, key);
            default:
                throw new IllegalArgumentException("Thuật toán không hỗ trợ: " + algorithm);
        }
    }
    private static int parseInt(String key, String message) {
        try {
            return Integer.parseInt(key);
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException(message);
        }
    }
}
