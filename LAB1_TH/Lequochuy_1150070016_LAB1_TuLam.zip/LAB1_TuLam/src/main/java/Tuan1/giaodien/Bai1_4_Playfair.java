package Tuan1.giaodien;
import java.util.Locale;
public class Bai1_4_Playfair extends javax.swing.JFrame {
    public Bai1_4_Playfair() {
        initComponents();
        setLocationRelativeTo(null);
    }
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Playfair Cipher");
        getContentPane().setLayout(new java.awt.BorderLayout());
        panel_main = new javax.swing.JPanel();
        panel_main.setBackground(new java.awt.Color(214, 217, 223));
        panel_main.setPreferredSize(new java.awt.Dimension(720, 458));
        panel_main.setLayout(new java.awt.GridBagLayout());
        lbl_title = new javax.swing.JLabel();
        lbl_title.setText("MẬT MÃ PLAYFAIR");
        lbl_title.setFont(new java.awt.Font("Segoe UI", 1, 18));
        lbl_title.setPreferredSize(new java.awt.Dimension(570, 34));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(20, 20, 8, 20);
        panel_main.add(lbl_title, gridBagConstraints);
        lbl_plaintext = new javax.swing.JLabel();
        lbl_plaintext.setText("Plaintext:");
        lbl_plaintext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_plaintext.setPreferredSize(new java.awt.Dimension(98, 22));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 14, 14);
        panel_main.add(lbl_plaintext, gridBagConstraints);
        scroll_plaintext = new javax.swing.JScrollPane();
        scroll_plaintext.setPreferredSize(new java.awt.Dimension(566, 66));
        txt_plaintext = new javax.swing.JTextArea();
        txt_plaintext.setColumns(40);
        txt_plaintext.setRows(3);
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        scroll_plaintext.setViewportView(txt_plaintext);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 1;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 14, 20);
        panel_main.add(scroll_plaintext, gridBagConstraints);
        lbl_key = new javax.swing.JLabel();
        lbl_key.setText("Key:");
        lbl_key.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_key.setPreferredSize(new java.awt.Dimension(98, 24));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 14, 14);
        panel_main.add(lbl_key, gridBagConstraints);
        panel_key = new javax.swing.JPanel();
        panel_key.setBackground(new java.awt.Color(214, 217, 223));
        panel_key.setLayout(new java.awt.GridBagLayout());
        txt_key = new javax.swing.JTextField();
        txt_key.setText("KEYWORD");
        txt_key.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_key.setPreferredSize(new java.awt.Dimension(146, 24));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_key.add(txt_key, gridBagConstraints);
        lbl_hint = new javax.swing.JLabel();
        lbl_hint.setText("Chỉ gồm chữ A-Z, ví dụ KEYWORD");
        lbl_hint.setFont(new java.awt.Font("Segoe UI", 0, 12));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 14, 0, 0);
        panel_key.add(lbl_hint, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 14, 20);
        panel_main.add(panel_key, gridBagConstraints);
        lbl_matrix = new javax.swing.JLabel();
        lbl_matrix.setText("Key Matrix:");
        lbl_matrix.setFont(new java.awt.Font("Segoe UI", 0, 12));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 14, 14);
        panel_main.add(lbl_matrix, gridBagConstraints);
        panel_matrix = new javax.swing.JPanel();
        panel_matrix.setBackground(new java.awt.Color(214, 217, 223));
        panel_matrix.setLayout(new java.awt.GridBagLayout());
        scroll_matrix = new javax.swing.JScrollPane();
        scroll_matrix.setPreferredSize(new java.awt.Dimension(166, 108));
        txt_matrix = new javax.swing.JTextArea();
        txt_matrix.setColumns(9);
        txt_matrix.setRows(5);
        txt_matrix.setLineWrap(false);
        txt_matrix.setFont(new java.awt.Font("Monospaced", 1, 14));
        txt_matrix.setEditable(false);
        scroll_matrix.setViewportView(txt_matrix);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 0;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_matrix.add(scroll_matrix, gridBagConstraints);
        btn_matrix = new javax.swing.JButton();
        btn_matrix.setText("Generate Key Matrix");
        btn_matrix.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_matrix.setPreferredSize(new java.awt.Dimension(166, 26));
        btn_matrix.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_matrixActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 0;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 14, 0, 0);
        panel_matrix.add(btn_matrix, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 14, 20);
        panel_main.add(panel_matrix, gridBagConstraints);
        lbl_ciphertext = new javax.swing.JLabel();
        lbl_ciphertext.setText("Ciphertext:");
        lbl_ciphertext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 16, 14);
        panel_main.add(lbl_ciphertext, gridBagConstraints);
        scroll_ciphertext = new javax.swing.JScrollPane();
        scroll_ciphertext.setPreferredSize(new java.awt.Dimension(566, 66));
        txt_ciphertext = new javax.swing.JTextArea();
        txt_ciphertext.setColumns(40);
        txt_ciphertext.setRows(3);
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        scroll_ciphertext.setViewportView(txt_ciphertext);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 1;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 16, 20);
        panel_main.add(scroll_ciphertext, gridBagConstraints);
        panel_actions = new javax.swing.JPanel();
        panel_actions.setBackground(new java.awt.Color(214, 217, 223));
        panel_actions.setLayout(new java.awt.GridBagLayout());
        btn_encrypt = new javax.swing.JButton();
        btn_encrypt.setText("Encrypt");
        btn_encrypt.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_encrypt.setPreferredSize(new java.awt.Dimension(96, 26));
        btn_encrypt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_encryptActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_actions.add(btn_encrypt, gridBagConstraints);
        btn_decrypt = new javax.swing.JButton();
        btn_decrypt.setText("Decrypt");
        btn_decrypt.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_decrypt.setPreferredSize(new java.awt.Dimension(96, 26));
        btn_decrypt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_decryptActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 14, 0, 0);
        panel_actions.add(btn_decrypt, gridBagConstraints);
        btn_open = new javax.swing.JButton();
        btn_open.setText("Open Ciphertext File");
        btn_open.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_open.setPreferredSize(new java.awt.Dimension(166, 26));
        btn_open.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_openActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 14, 0, 0);
        panel_actions.add(btn_open, gridBagConstraints);
        btn_save = new javax.swing.JButton();
        btn_save.setText("Save Ciphertext File");
        btn_save.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_save.setPreferredSize(new java.awt.Dimension(166, 26));
        btn_save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_saveActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 14, 0, 0);
        panel_actions.add(btn_save, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 16, 20);
        panel_main.add(panel_actions, gridBagConstraints);
        lbl_status = new javax.swing.JLabel();
        lbl_status.setText("Sẵn sàng.");
        lbl_status.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_status.setPreferredSize(new java.awt.Dimension(566, 22));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 6;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(lbl_status, gridBagConstraints);
        getContentPane().add(panel_main, java.awt.BorderLayout.CENTER);
        pack();
    }
    private void btn_matrixActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            txt_matrix.setText(Bai1_4_Playfair.getKeyMatrix(txt_key.getText()));
            lbl_status.setText("Đã tạo ma trận khóa.");
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }
    private void btn_encryptActionPerformed(java.awt.event.ActionEvent evt) {
        String text = txt_plaintext.getText();
        if (text.isEmpty()) {
            showError("Hãy nhập Plaintext trước khi mã hóa.");
            return;
        }
        try {
            String key = txt_key.getText();
            txt_ciphertext.setText(Bai1_4_Playfair.encrypt(text, key));
            txt_matrix.setText(Bai1_4_Playfair.getKeyMatrix(key));
            lbl_status.setText("Đã mã hóa.");
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }
    private void btn_decryptActionPerformed(java.awt.event.ActionEvent evt) {
        String text = txt_ciphertext.getText();
        if (text.isEmpty()) {
            showError("Hãy nhập Ciphertext trước khi giải mã.");
            return;
        }
        try {
            String key = txt_key.getText();
            txt_plaintext.setText(Bai1_4_Playfair.decrypt(text, key));
            txt_matrix.setText(Bai1_4_Playfair.getKeyMatrix(key));
            lbl_status.setText("Đã giải mã.");
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }
    private void btn_openActionPerformed(java.awt.event.ActionEvent evt) {
        String path = FileTextIO.openText(this, txt_ciphertext);
        if (path != null) lbl_status.setText("Đã mở tệp: " + path);
    }
    private void btn_saveActionPerformed(java.awt.event.ActionEvent evt) {
        String path = FileTextIO.saveText(this, txt_ciphertext, "playfair_ciphertext.txt");
        if (path != null) lbl_status.setText("Đã lưu tệp: " + path);
    }
    private void showError(String message) {
        lbl_status.setText(message);
        javax.swing.JOptionPane.showMessageDialog(this, message, "Dữ liệu không hợp lệ",
                javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new Bai1_4_Playfair().setVisible(true));
    }
    private javax.swing.JPanel panel_main;
    private javax.swing.JLabel lbl_title;
    private javax.swing.JLabel lbl_plaintext;
    private javax.swing.JScrollPane scroll_plaintext;
    private javax.swing.JTextArea txt_plaintext;
    private javax.swing.JLabel lbl_key;
    private javax.swing.JPanel panel_key;
    private javax.swing.JTextField txt_key;
    private javax.swing.JLabel lbl_hint;
    private javax.swing.JLabel lbl_matrix;
    private javax.swing.JPanel panel_matrix;
    private javax.swing.JScrollPane scroll_matrix;
    private javax.swing.JTextArea txt_matrix;
    private javax.swing.JButton btn_matrix;
    private javax.swing.JLabel lbl_ciphertext;
    private javax.swing.JScrollPane scroll_ciphertext;
    private javax.swing.JTextArea txt_ciphertext;
    private javax.swing.JPanel panel_actions;
    private javax.swing.JButton btn_encrypt;
    private javax.swing.JButton btn_decrypt;
    private javax.swing.JButton btn_open;
    private javax.swing.JButton btn_save;
    private javax.swing.JLabel lbl_status;
    private static final class PlayfairEngine {
    private final char[][] matrix;
    public PlayfairEngine(String key) {
        this.matrix = makeMatrix(key);
    }
    public String encrypt(String text) {
        return process(text, true);
    }
    public String decrypt(String text) {
        return process(text, false);
    }
    public static String encrypt(String text, String key) {
        return new PlayfairEngine(key).encrypt(text);
    }
    public static String decrypt(String text, String key) {
        return new PlayfairEngine(key).decrypt(text);
    }
    public static String getKeyMatrix(String key) {
        StringBuilder display = new StringBuilder();
        for (char[] row : makeMatrix(key)) {
            for (char c : row) display.append(c).append(' ');
            display.append('\n');
        }
        return display.toString();
    }
    private static char[][] makeMatrix(String key) {
        String upper = key.trim().toUpperCase(Locale.ROOT);
        if (!upper.matches("[A-Z]+")) {
            throw new IllegalArgumentException("Khóa Playfair chỉ gồm A-Z.");
        }
        boolean[] used = new boolean[26];
        StringBuilder alphabet = new StringBuilder();
        for (char c : (upper + "ABCDEFGHIKLMNOPQRSTUVWXYZ").toCharArray()) {
            if (c == 'J') c = 'I';
            if (!used[c - 'A']) {
                used[c - 'A'] = true;
                alphabet.append(c);
            }
        }
        char[][] output = new char[5][5];
        for (int i = 0; i < 25; i++) {
            output[i / 5][i % 5] = alphabet.charAt(i);
        }
        return output;
    }
    private static String normalize(String text) {
        StringBuilder clean = new StringBuilder();
        for (char c : text.toUpperCase(Locale.ROOT).toCharArray()) {
            if (c >= 'A' && c <= 'Z') clean.append(c == 'J' ? 'I' : c);
        }
        if (clean.length() == 0) {
            throw new IllegalArgumentException("Văn bản Playfair cần chữ A-Z.");
        }
        return clean.toString();
    }
    private static String makePairs(String normalized) {
        StringBuilder pairs = new StringBuilder();
        int i = 0;
        while (i < normalized.length()) {
            char first = normalized.charAt(i++);
            char second;
            if (i >= normalized.length() || first == normalized.charAt(i)) {
                second = first == 'X' ? 'Q' : 'X';
            } else {
                second = normalized.charAt(i++);
            }
            pairs.append(first).append(second);
        }
        return pairs.toString();
    }
    private int[] locate(char c) {
        for (int row = 0; row < 5; row++) {
            for (int col = 0; col < 5; col++) {
                if (matrix[row][col] == c) return new int[] {row, col};
            }
        }
        throw new IllegalArgumentException("Ký tự không có trong bảng khóa.");
    }
    private String process(String text, boolean encrypt) {
        String data = normalize(text);
        if (encrypt) data = makePairs(data);
        else if (data.length() % 2 != 0) {
            throw new IllegalArgumentException("Bản mã Playfair phải có độ dài chẵn.");
        }
        int step = encrypt ? 1 : 4;
        StringBuilder output = new StringBuilder();
        for (int i = 0; i < data.length(); i += 2) {
            int[] a = locate(data.charAt(i));
            int[] b = locate(data.charAt(i + 1));
            if (a[0] == b[0]) {
                output.append(matrix[a[0]][(a[1] + step) % 5]);
                output.append(matrix[b[0]][(b[1] + step) % 5]);
            } else if (a[1] == b[1]) {
                output.append(matrix[(a[0] + step) % 5][a[1]]);
                output.append(matrix[(b[0] + step) % 5][b[1]]);
            } else {
                output.append(matrix[a[0]][b[1]]);
                output.append(matrix[b[0]][a[1]]);
            }
        }
        return output.toString();
    }
    }
    public static String encrypt(String text, String key) {
        return PlayfairEngine.encrypt(text, key);
    }
    public static String decrypt(String text, String key) {
        return PlayfairEngine.decrypt(text, key);
    }
    public static String getKeyMatrix(String key) {
        return PlayfairEngine.getKeyMatrix(key);
    }
}
