package Tuan1.giaodien;
import java.util.Locale;
public class bai2nangcao extends javax.swing.JFrame {
    public bai2nangcao() {
        initComponents();
        setLocationRelativeTo(null);
    }
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Phân tích mật mã cổ điển");
        getContentPane().setLayout(new java.awt.BorderLayout());
        panel_main = new javax.swing.JPanel();
        panel_main.setBackground(new java.awt.Color(214, 217, 223));
        panel_main.setPreferredSize(new java.awt.Dimension(800, 580));
        panel_main.setLayout(new java.awt.GridBagLayout());
        lbl_title = new javax.swing.JLabel();
        lbl_title.setText("PHÂN TÍCH (TẤN CÔNG) MẬT MÃ CỔ ĐIỂN");
        lbl_title.setFont(new java.awt.Font("Segoe UI", 1, 18));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(20, 20, 16, 20);
        panel_main.add(lbl_title, gridBagConstraints);
        lbl_cipher = new javax.swing.JLabel();
        lbl_cipher.setText("Ciphertext:");
        lbl_cipher.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_cipher.setPreferredSize(new java.awt.Dimension(98, 24));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 12, 14);
        panel_main.add(lbl_cipher, gridBagConstraints);
        scroll_txt_cipher = new javax.swing.JScrollPane();
        scroll_txt_cipher.setPreferredSize(new java.awt.Dimension(620, 50));
        txt_cipher = new javax.swing.JTextArea();
        txt_cipher.setColumns(40);
        txt_cipher.setRows(3);
        txt_cipher.setLineWrap(true);
        txt_cipher.setWrapStyleWord(true);
        txt_cipher.setEditable(true);
        txt_cipher.setFont(new java.awt.Font("Segoe UI", 0, 12));
        scroll_txt_cipher.setViewportView(txt_cipher);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(scroll_txt_cipher, gridBagConstraints);
        panel_actions = new javax.swing.JPanel();
        panel_actions.setBackground(new java.awt.Color(214, 217, 223));
        panel_actions.setLayout(new java.awt.GridBagLayout());
        btn_bruteforce = new javax.swing.JButton();
        btn_bruteforce.setText("Brute Force Caesar");
        btn_bruteforce.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_bruteforce.setPreferredSize(new java.awt.Dimension(170, 28));
        btn_bruteforce.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_bruteforceActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_actions.add(btn_bruteforce, gridBagConstraints);
        btn_frequency = new javax.swing.JButton();
        btn_frequency.setText("Frequency Analysis");
        btn_frequency.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_frequency.setPreferredSize(new java.awt.Dimension(170, 28));
        btn_frequency.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_frequencyActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 14, 0, 0);
        panel_actions.add(btn_frequency, gridBagConstraints);
        panel_actions_space = new javax.swing.JLabel();
        panel_actions_space.setText("");
        panel_actions_space.setFont(new java.awt.Font("Segoe UI", 0, 12));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_actions.add(panel_actions_space, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 14, 20);
        panel_main.add(panel_actions, gridBagConstraints);
        lbl_known = new javax.swing.JLabel();
        lbl_known.setText("Bản rõ đã biết:");
        lbl_known.setFont(new java.awt.Font("Segoe UI", 0, 12));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 14, 14);
        panel_main.add(lbl_known, gridBagConstraints);
        panel_known = new javax.swing.JPanel();
        panel_known.setBackground(new java.awt.Color(214, 217, 223));
        panel_known.setLayout(new java.awt.GridBagLayout());
        txt_known_plain = new javax.swing.JTextField();
        txt_known_plain.setText("HELLO");
        txt_known_plain.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_known_plain.setPreferredSize(new java.awt.Dimension(140, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 10);
        panel_known.add(txt_known_plain, gridBagConstraints);
        lbl_known_cipher = new javax.swing.JLabel();
        lbl_known_cipher.setText("Bản mã:");
        lbl_known_cipher.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_known_cipher.setPreferredSize(new java.awt.Dimension(50, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 10);
        panel_known.add(lbl_known_cipher, gridBagConstraints);
        txt_known_cipher = new javax.swing.JTextField();
        txt_known_cipher.setText("RIJVS");
        txt_known_cipher.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_known_cipher.setPreferredSize(new java.awt.Dimension(140, 28));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 10);
        panel_known.add(txt_known_cipher, gridBagConstraints);
        btn_known = new javax.swing.JButton();
        btn_known.setText("Known Plaintext (Vigenere)");
        btn_known.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_known.setPreferredSize(new java.awt.Dimension(220, 28));
        btn_known.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_knownActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_known.add(btn_known, gridBagConstraints);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 14, 20);
        panel_main.add(panel_known, gridBagConstraints);
        lbl_result = new javax.swing.JLabel();
        lbl_result.setText("Kết quả:");
        lbl_result.setFont(new java.awt.Font("Segoe UI", 0, 12));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 12, 14);
        panel_main.add(lbl_result, gridBagConstraints);
        scroll_txt_result = new javax.swing.JScrollPane();
        scroll_txt_result.setPreferredSize(new java.awt.Dimension(620, 250));
        txt_result = new javax.swing.JTextArea();
        txt_result.setColumns(40);
        txt_result.setRows(3);
        txt_result.setLineWrap(false);
        txt_result.setWrapStyleWord(false);
        txt_result.setEditable(false);
        txt_result.setFont(new java.awt.Font("Monospaced", 0, 14));
        scroll_txt_result.setViewportView(txt_result);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(scroll_txt_result, gridBagConstraints);
        lbl_status = new javax.swing.JLabel();
        lbl_status.setText("Sẵn sàng.");
        lbl_status.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_status.setPreferredSize(new java.awt.Dimension(620, 40));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 16, 20);
        panel_main.add(lbl_status, gridBagConstraints);
        getContentPane().add(panel_main, java.awt.BorderLayout.CENTER);
        pack();
    }
    private void btn_bruteforceActionPerformed(java.awt.event.ActionEvent evt) {
        String cipher = txt_cipher.getText().trim();
        if (cipher.isEmpty()) {
            hienLoi("Hãy nhập Ciphertext.");
            return;
        }
        try {
            txt_result.setText(bai2nangcao.caesarBruteForce(cipher));
            txt_result.setCaretPosition(0);
            trangThai("Đã thử đủ 26 khóa Caesar. Điểm tần suất chỉ là gợi ý.");
        } catch (IllegalArgumentException ex) {
            hienLoi(ex.getMessage());
        }
    }
    private void btn_frequencyActionPerformed(java.awt.event.ActionEvent evt) {
        String cipher = txt_cipher.getText().trim();
        if (cipher.isEmpty()) {
            hienLoi("Hãy nhập Ciphertext.");
            return;
        }
        try {
            txt_result.setText(bai2nangcao.frequency(cipher));
            txt_result.setCaretPosition(0);
            trangThai("Đã thống kê tần suất chữ cái.");
        } catch (IllegalArgumentException ex) {
            hienLoi(ex.getMessage());
        }
    }
    private void btn_knownActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            String key = bai2nangcao.knownPlaintext(txt_known_plain.getText(), txt_known_cipher.getText());
            txt_result.setText("Khóa Vigenère suy ra từng vị trí: " + key
                    + "\nNếu khóa ngắn hơn bản rõ, khóa sẽ lặp lại (KEY KEY ...).");
            txt_result.setCaretPosition(0);
            trangThai("Khóa suy ra: " + key);
        } catch (IllegalArgumentException ex) {
            hienLoi(ex.getMessage());
        }
    }
    private void trangThai(String text) {
        lbl_status.setText("<html>" + text.replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;") + "</html>");
        lbl_status.setToolTipText(text);
    }
    private void hienLoi(String message) {
        trangThai(message);
        javax.swing.JOptionPane.showMessageDialog(this, message, "Thông báo",
                javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new bai2nangcao().setVisible(true));
    }
    private javax.swing.JPanel panel_main;
    private javax.swing.JLabel lbl_title;
    private javax.swing.JLabel lbl_cipher;
    private javax.swing.JScrollPane scroll_txt_cipher;
    private javax.swing.JTextArea txt_cipher;
    private javax.swing.JPanel panel_actions;
    private javax.swing.JButton btn_bruteforce;
    private javax.swing.JButton btn_frequency;
    private javax.swing.JLabel panel_actions_space;
    private javax.swing.JLabel lbl_known;
    private javax.swing.JPanel panel_known;
    private javax.swing.JTextField txt_known_plain;
    private javax.swing.JLabel lbl_known_cipher;
    private javax.swing.JTextField txt_known_cipher;
    private javax.swing.JButton btn_known;
    private javax.swing.JLabel lbl_result;
    private javax.swing.JScrollPane scroll_txt_result;
    private javax.swing.JTextArea txt_result;
    private javax.swing.JLabel lbl_status;
    private static final double[] ENGLISH = {
        8.2, 1.5, 2.8, 4.3, 12.7, 2.2, 2.0, 6.1, 7.0, 0.15, 0.77, 4.0, 2.4,
        6.7, 7.5, 1.9, 0.095, 6.0, 6.3, 9.1, 2.8, 0.98, 2.4, 0.15, 2.0, 0.074
    };
public static String caesarBruteForce(String cipher) {
        if (cipher == null || cipher.isBlank()) {
            throw new IllegalArgumentException("Hãy nhập Ciphertext.");
        }
        if (cipher.chars().noneMatch(c -> c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z')) {
            throw new IllegalArgumentException("Bản mã cần có chữ cái A-Z để chấm điểm Caesar.");
        }
        int best = 0;
        double bestScore = -Double.MAX_VALUE;
        for (int key = 0; key < 26; key++) {
            double score = englishScore(Bai1_1_Caesar.decrypt(cipher, key));
            if (score > bestScore) {
                bestScore = score;
                best = key;
            }
        }
        StringBuilder result = new StringBuilder("k  | Bản rõ thử\n");
        for (int key = 0; key < 26; key++) {
            result.append(String.format(Locale.ROOT, "%2d | %s%s%n", key,
                    Bai1_1_Caesar.decrypt(cipher, key), key == best ? "   <== có nghĩa nhất" : ""));
        }
        result.append("Kết luận: khóa k = ").append(best).append(", bản rõ = ")
                .append(Bai1_1_Caesar.decrypt(cipher, best));
        return result.toString();
    }
    public static String frequency(String cipher) {
        if (cipher == null) {
            throw new IllegalArgumentException("Hãy nhập Ciphertext.");
        }
        int[] count = new int[26];
        int total = 0;
        for (char c : cipher.toUpperCase(Locale.ROOT).toCharArray()) {
            if (c >= 'A' && c <= 'Z') {
                count[c - 'A']++;
                total++;
            }
        }
        if (total == 0) {
            return "Bản mã không có chữ cái A-Z.";
        }
        StringBuilder result = new StringBuilder("Chữ | Số lần | Tần suất\n");
        for (int i = 0; i < count.length; i++) {
            if (count[i] > 0) {
                result.append(String.format(Locale.ROOT, " %c  |   %2d   | %5.1f %%%n",
                        (char) ('A' + i), count[i], 100.0 * count[i] / total));
            }
        }
        return result.append("Tổng số chữ: ").append(total).toString();
    }
    public static String knownPlaintext(String plain, String cipher) {
        if (plain == null || cipher == null) {
            throw new IllegalArgumentException("Hãy nhập bản rõ và bản mã.");
        }
        String p = plain.trim().toUpperCase(Locale.ROOT);
        String c = cipher.trim().toUpperCase(Locale.ROOT);
        if (p.isEmpty() || p.length() != c.length()) {
            throw new IllegalArgumentException("Bản rõ và bản mã phải cùng độ dài.");
        }
        if (!p.matches("[A-Z]+") || !c.matches("[A-Z]+")) {
            throw new IllegalArgumentException("Chỉ nhập chữ A-Z, không dấu, không khoảng trắng.");
        }
        StringBuilder key = new StringBuilder();
        for (int i = 0; i < p.length(); i++) {
            key.append((char) ('A' + Math.floorMod(c.charAt(i) - p.charAt(i), 26)));
        }
        return key.toString();
    }
    private static double englishScore(String text) {
        double score = 0;
        for (char c : text.toUpperCase(Locale.ROOT).toCharArray()) {
            if (c >= 'A' && c <= 'Z') {
                score += Math.log(ENGLISH[c - 'A']);
            }
        }
        return score;
    }
}
