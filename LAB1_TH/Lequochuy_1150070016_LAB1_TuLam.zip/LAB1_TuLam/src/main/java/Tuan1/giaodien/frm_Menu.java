package Tuan1.giaodien;
public class frm_Menu extends javax.swing.JFrame {
    public frm_Menu() {
        initComponents();
        setLocationRelativeTo(null);
    }
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("LAB 1 - Mã hóa đối xứng cổ điển");
        getContentPane().setLayout(new java.awt.BorderLayout());
        panel_main = new javax.swing.JPanel();
        panel_main.setBackground(new java.awt.Color(214, 217, 223));
        panel_main.setPreferredSize(new java.awt.Dimension(680, 266));
        panel_main.setLayout(new java.awt.GridBagLayout());
        lbl_title = new javax.swing.JLabel();
        lbl_title.setText("LAB 1 - MÃ HÓA ĐỐI XỨNG CỔ ĐIỂN");
        lbl_title.setFont(new java.awt.Font("Segoe UI", 1, 20));
        lbl_title.setPreferredSize(new java.awt.Dimension(640, 38));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(20, 20, 10, 20);
        panel_main.add(lbl_title, gridBagConstraints);
        lbl_choose = new javax.swing.JLabel();
        lbl_choose.setText("Chọn một bài để mở form tương ứng:");
        lbl_choose.setFont(new java.awt.Font("Segoe UI", 0, 12));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 16, 20);
        panel_main.add(lbl_choose, gridBagConstraints);
        btn_bai1_1 = new javax.swing.JButton();
        btn_bai1_1.setText("1.1 Caesar");
        btn_bai1_1.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_bai1_1.setPreferredSize(new java.awt.Dimension(196, 26));
        btn_bai1_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_bai1_1ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 16, 0);
        panel_main.add(btn_bai1_1, gridBagConstraints);
        btn_bai1_2 = new javax.swing.JButton();
        btn_bai1_2.setText("1.2 Vigenère");
        btn_bai1_2.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_bai1_2.setPreferredSize(new java.awt.Dimension(196, 26));
        btn_bai1_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_bai1_2ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 14, 16, 0);
        panel_main.add(btn_bai1_2, gridBagConstraints);
        btn_bai1_3 = new javax.swing.JButton();
        btn_bai1_3.setText("1.3 Rail Fence");
        btn_bai1_3.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_bai1_3.setPreferredSize(new java.awt.Dimension(196, 26));
        btn_bai1_3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_bai1_3ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 14, 16, 20);
        panel_main.add(btn_bai1_3, gridBagConstraints);
        btn_bai1_4 = new javax.swing.JButton();
        btn_bai1_4.setText("1.4 Playfair");
        btn_bai1_4.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_bai1_4.setPreferredSize(new java.awt.Dimension(196, 26));
        btn_bai1_4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_bai1_4ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 16, 0);
        panel_main.add(btn_bai1_4, gridBagConstraints);
        btn_bai1_5 = new javax.swing.JButton();
        btn_bai1_5.setText("1.5 Transposition");
        btn_bai1_5.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_bai1_5.setPreferredSize(new java.awt.Dimension(196, 26));
        btn_bai1_5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_bai1_5ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 14, 16, 0);
        panel_main.add(btn_bai1_5, gridBagConstraints);
        btn_bai1_6 = new javax.swing.JButton();
        btn_bai1_6.setText("1.6 Autokey");
        btn_bai1_6.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_bai1_6.setPreferredSize(new java.awt.Dimension(196, 26));
        btn_bai1_6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_bai1_6ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 14, 16, 20);
        panel_main.add(btn_bai1_6, gridBagConstraints);
        btn_nangcao1 = new javax.swing.JButton();
        btn_nangcao1.setText("Nâng cao 01 - Tổng hợp");
        btn_nangcao1.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_nangcao1.setPreferredSize(new java.awt.Dimension(196, 26));
        btn_nangcao1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_nangcao1ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 20, 16, 0);
        panel_main.add(btn_nangcao1, gridBagConstraints);
        btn_nangcao2 = new javax.swing.JButton();
        btn_nangcao2.setText("Nâng cao 02 - Tấn công");
        btn_nangcao2.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_nangcao2.setPreferredSize(new java.awt.Dimension(196, 26));
        btn_nangcao2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_nangcao2ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 14, 16, 0);
        panel_main.add(btn_nangcao2, gridBagConstraints);
        btn_sql = new javax.swing.JButton();
        btn_sql.setText("Kết nối SQL Server");
        btn_sql.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_sql.setPreferredSize(new java.awt.Dimension(196, 26));
        btn_sql.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_sqlActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 14, 16, 20);
        panel_main.add(btn_sql, gridBagConstraints);
        lbl_footer = new javax.swing.JLabel();
        lbl_footer.setText("Mỗi form mở ra là một cửa sổ riêng; đóng form con không làm tắt chương trình.");
        lbl_footer.setFont(new java.awt.Font("Segoe UI", 0, 12));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = 2;
        gridBagConstraints.anchor = 18;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.insets = new java.awt.Insets(4, 20, 16, 20);
        panel_main.add(lbl_footer, gridBagConstraints);
        getContentPane().add(panel_main, java.awt.BorderLayout.CENTER);
        pack();
    }
    private void btn_bai1_1ActionPerformed(java.awt.event.ActionEvent evt) {
        new Bai1_1_Caesar().setVisible(true);
    }
    private void btn_bai1_2ActionPerformed(java.awt.event.ActionEvent evt) {
        new Bai1_2_Vigenere().setVisible(true);
    }
    private void btn_bai1_3ActionPerformed(java.awt.event.ActionEvent evt) {
        new Bai1_3_RailFence().setVisible(true);
    }
    private void btn_bai1_4ActionPerformed(java.awt.event.ActionEvent evt) {
        new Bai1_4_Playfair().setVisible(true);
    }
    private void btn_bai1_5ActionPerformed(java.awt.event.ActionEvent evt) {
        new Bai1_5_Transposition().setVisible(true);
    }
    private void btn_bai1_6ActionPerformed(java.awt.event.ActionEvent evt) {
        new Bai1_6_Autokey().setVisible(true);
    }
    private void btn_nangcao1ActionPerformed(java.awt.event.ActionEvent evt) {
        new bai1nangcao().setVisible(true);
    }
    private void btn_nangcao2ActionPerformed(java.awt.event.ActionEvent evt) {
        new bai2nangcao().setVisible(true);
    }
    private void btn_sqlActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_KetNoiSQL().setVisible(true);
    }
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new frm_Menu().setVisible(true));
    }
    private javax.swing.JPanel panel_main;
    private javax.swing.JLabel lbl_title;
    private javax.swing.JLabel lbl_choose;
    private javax.swing.JButton btn_bai1_1;
    private javax.swing.JButton btn_bai1_2;
    private javax.swing.JButton btn_bai1_3;
    private javax.swing.JButton btn_bai1_4;
    private javax.swing.JButton btn_bai1_5;
    private javax.swing.JButton btn_bai1_6;
    private javax.swing.JLabel lbl_footer;
    private javax.swing.JButton btn_nangcao1;
    private javax.swing.JButton btn_nangcao2;
    private javax.swing.JButton btn_sql;
}
